﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using NLog;
using Report.Provider.Entity;
using Report.Provider.Factory;

namespace ReportProgram
{
    public class Program
    {
        private static Logger logger = LogManager.GetCurrentClassLogger();
        private static int FileProcessedCount = 0;
        public static void Main(string[] args)
        {
            string reportFolderName = ConfigurationManager.AppSettings["ReportFolderName"];

            IEnumerable<string> filePaths = Directory.EnumerateFiles(reportFolderName, "*.csv");
            ProviderRequest providerRequest = GetConfigData();
                foreach (string file in filePaths)
            {
                string fileName = file.Split('\\').Last();
                Console.WriteLine("Start of file processing for {0}", fileName);
                BaseFactory fileProcessor = new BaseFactory();
                try
                {
                    providerRequest.File = file;
                    ProviderResponse processedOutput = fileProcessor.ProcessFiles(providerRequest);
                    if (processedOutput.FileLinesCount > 0)
                    {
                        FileProcessedCount++;
                        if (processedOutput.AbnormalCount > 0)
                        {
                            Console.WriteLine("Number of abnormal values found in file {0}: {1} out of {2} lines", fileName, processedOutput.AbnormalCount, processedOutput.FileLinesCount);
                            Console.WriteLine("Please find below the list of abnormal values in file {0}", fileName);
                            foreach (ProviderItem data in processedOutput.ProviderItem)
                            {
                                Console.WriteLine("{0} {1} {2} {3}", fileName, data.Date, data.RowValue, data.MedianValue);
                            }
                        }
                        else
                        {
                            Console.WriteLine("No abnormal values found in file {0}!", fileName);
                        }

                        Console.WriteLine("End of file processing for {0}", fileName);
                    }
                }
                catch (Exception reportException)
                {
                    string errorMessage = string.Format("An error occurred while processing file {0}. Error details: {1}", fileName, reportException.Message);
                    Console.WriteLine(errorMessage);
                    logger.Error(errorMessage);
                }
            }

            if (FileProcessedCount.Equals(0))
                Console.WriteLine("No files present for processing");
            else
                Console.WriteLine("Processed {0} file(s)", FileProcessedCount);

            NLog.LogManager.Shutdown();
            Console.WriteLine("Press any key to exit...");
            Console.ReadLine();
        }

        private static ProviderRequest GetConfigData()
        {
            ProviderRequest input = null;
            try
            {
                // Retrieve column indices from App.config
                input = new ProviderRequest()
                {
                    DateTimeColumn = Convert.ToInt32(ConfigurationManager.AppSettings["DateTimeColumn"].ToString()),
                    MedianReferenceColumn = Convert.ToInt32(ConfigurationManager.AppSettings["MedianReferenceColumn"].ToString()),
                    PercentageFactor = Convert.ToInt32(ConfigurationManager.AppSettings["PercentageFactor"].ToString())
                };
            }
            catch (Exception ex)
            {
                string errorMessage = "Error while reading configuration values. Please ensure the required parameters are configured in the application configuration file";
                Console.WriteLine(errorMessage);
                logger.Error(ex.Message, errorMessage);
                return input;
            }

            return input;
        }
    }
}
