﻿namespace Report.Provider.Utility
{
    /// <summary>
    /// Common repository for all enums required across the application
    /// </summary>
    public class ProviderEnum
    {
        /// <summary>
        /// Provider type identification
        /// </summary>
        public enum ProviderType
        {
            LP = 1,
            TOU = 2
        }
    }
}
