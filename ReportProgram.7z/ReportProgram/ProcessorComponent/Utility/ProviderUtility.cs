﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Report.Provider.Entity;

namespace Report.Provider
{
    /// <summary>
    /// Methods executing common functionalities are defined in the class
    /// </summary>
    public static class ProviderUtility
    {
        #region Public members
        public static string FilePath { get; set; }
        #endregion

        #region Public Methods
        /// <summary>
        /// Calculate median for a column configured in configuration file
        /// </summary>
        /// <param name="dataForMedianCalculation">Data containing in a CSV column</param>
        /// <returns>Median</returns>
        public static double CalculateMedian(double[] dataForMedianCalculation)
        {
            var valuesList = dataForMedianCalculation.OrderBy(x => x).ToList();
            double middle = (valuesList.Count - 1) / 2.0;
            return (valuesList[(int)(middle)] + valuesList[(int)(middle + 0.5)]) / 2;
        }

        /// <summary>
        /// Retrieve file content from a path, for a particular CSV column
        /// </summary>
        /// <param name="input">Data required to process files</param>
        /// <returns>File contents</returns>
        public static IEnumerable<string> GetFileData(ProviderRequest input)
        {
            // Read lines from the file in an efficient way. 
            // Exclude header and include columns with Date Time column and Median reference column
            var test = (from line in File.ReadLines(input.File).Skip(1).Select(x => x.Split(','))
                        select string.Concat(line[input.DateTimeColumn], ",", line[input.MedianReferenceColumn]));
            return test;
        }

        /// <summary>
        /// Retrieves array of data from a particular column in the CSV file
        /// </summary>
        /// <param name="lines">Complete CSV file data</param>
        /// <param name="medianIndex">Index of the column in the CSV file</param>
        /// <returns>Column data for all lines in CSV file</returns>
        public static double[] GetMedianData(IEnumerable<string> lines, int medianIndex)
        {
            // Fetch data at medianIndex column in the collection upon which median can be calculated
            return (from line in lines
                    let elements = line.Split(',')
                    select Convert.ToDouble(elements[medianIndex])).ToArray();
        }
        #endregion
    }
}
