﻿namespace Report.Provider.Entity
{
    /// <summary>
    /// Entity data to hold data related to abnormal values
    /// </summary>
    public class ProviderItem
    {
        #region Public members
        public string FileName { get; set; }
        public string Date { get; set; }
        public string RowValue { get; set; }
        public string MedianValue { get; set; }
        #endregion
    }
}
