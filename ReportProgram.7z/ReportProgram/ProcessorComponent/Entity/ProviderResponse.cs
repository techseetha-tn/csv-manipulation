﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Report.Provider.Entity
{
    /// <summary>
    /// Entity data to hold the result post processing of files
    /// </summary>
    public class ProviderResponse
    {
        #region Public members
        public int FileLinesCount { get; set; }
        public int AbnormalCount { get; set; }
        public int FileProcessedCount { get; set; }
        public List<ProviderItem> ProviderItem { get; set; }
        #endregion
    }
}
