﻿namespace Report.Provider.Entity
{
    /// <summary>
    /// Entity data to hold request information to process files
    /// </summary>
    public class ProviderRequest
    {
        #region Public members
        public int DateTimeColumn { get; set; }
        public int MedianReferenceColumn { get; set; }
        public double PercentageFactor { get; set; }
        public string File { get; set; }
        #endregion
    }
}
