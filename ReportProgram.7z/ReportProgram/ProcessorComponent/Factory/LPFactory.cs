﻿namespace Report.Provider.Factory
{
    public class LPFactory : BaseFactory
    {
        public LPFactory()
        {
            // Handle initialization here
        }
    }
}
