﻿namespace Report.Provider.Factory
{
    public class TOUFactory : BaseFactory
    {
        public TOUFactory()
        {
            // Handle initialization here
        }
    }
}
