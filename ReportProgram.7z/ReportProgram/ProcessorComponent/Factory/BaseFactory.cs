﻿using System;
using System.Collections.Generic;
using System.Linq;
using Report.Provider.Entity;
using Report.Provider.Utility;

namespace Report.Provider.Factory
{
    public class BaseFactory
    {
        #region Public members
        public double Median { get; set; }
        #endregion

        #region Public Methods
        public BaseFactory()
        {
            // Constructor for data initialization, if any
        }

        /// <summary>
        /// Process files based on template type to report abnormal data
        /// </summary>
        /// <param name="input">Data required to process files</param>
        /// <returns>Data associated with abnormal values</returns>
        public virtual ProviderResponse ProcessFiles(ProviderRequest input)
        {
            string fileType = input.File.StartsWith("LP") ? ProviderEnum.ProviderType.LP.ToString() : ProviderEnum.ProviderType.TOU.ToString();
            ProviderResponse response = new ProviderResponse();

            // Invoke file processing operation for the different file types
            switch (fileType)
            {
                case "LP":
                    LPFactory lpFactory = new LPFactory();
                    response = lpFactory.ProcessTemplateFiles(lpFactory, input);
                    break;
                case "TOU":
                    TOUFactory touFactory = new TOUFactory();
                    response = touFactory.ProcessTemplateFiles(touFactory, input);
                    break;
                default:
                    break;
            }

            return response;
        }
        #endregion

        #region Protected Methods

        /// <summary>
        /// Process files to report abnormal data
        /// </summary>
        /// <param name="childFactory">Template driven processor</param>
        /// <param name="input">Data required to process files</param>
        /// <returns>Data associated with abnormal values</returns>
        protected ProviderResponse ProcessTemplateFiles(BaseFactory childFactory, ProviderRequest input)
        {
            ProviderResponse processorOutput = new ProviderResponse();

            // Get file contents including only the Date Time and Median reference column
            var lines = ProviderUtility.GetFileData(input).AsQueryable();
            processorOutput.FileLinesCount = lines != null ? lines.Count() : 0;
            if (processorOutput.FileLinesCount > 0)
            {
                List<ProviderItem> lpFactoryEntity = new List<ProviderItem>();

                // Get data required for Median calculation
                double[] dataForMedianCalculation = ProviderUtility.GetMedianData(lines, 1);

                // Calculate Median
                double median = ProviderUtility.CalculateMedian(dataForMedianCalculation);

                // Find values x% above or below the median
                double aboveMedianByPercentageFactor = median + (median * (input.PercentageFactor / 100));
                double belowMedianByPercentageFactor = median - (median * (input.PercentageFactor / 100));

                // Get all abnormal values are relevant data
                lpFactoryEntity = lines.Where(x => Convert.ToDouble(x.Split(',')[1]) > aboveMedianByPercentageFactor || Convert.ToDouble(x.Split(',')[1]) < belowMedianByPercentageFactor).Select(x => x.Split(',')).Select(y =>
                   new ProviderItem()
                   {
                       Date = y[0],
                       RowValue = y[1],
                       MedianValue = median.ToString(),
                   }).ToList();

                processorOutput.AbnormalCount = lpFactoryEntity != null ? lpFactoryEntity.Count() : 0;
                processorOutput.ProviderItem = lpFactoryEntity;
            }

            return processorOutput;
        }
        #endregion
    }
}
