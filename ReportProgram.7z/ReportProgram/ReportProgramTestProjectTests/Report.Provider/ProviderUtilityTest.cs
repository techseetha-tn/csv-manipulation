﻿using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Report.Provider;

namespace ReportProgramTestProject.Tests
{
    [TestClass()]
    public class ProviderUtilityTest
    {
        /// <summary>
        /// Test method to validate if GetMedianData retrieves the data required for Median calculation
        /// </summary>
        [TestMethod()]
        public void GetMedianData_CheckValidCountTest()
        {
            IQueryable<string> mockFileData = new string[] {
                "210095893,210095893,ED031000001,31/08/2015 19:00:00,Export varh Total,3.900000,kvarh",
"210095893,210095893,ED031000001,31 / 08 / 2015 19:15:00,Export varh Total,4.100000,kvarh",
"210095893,210095893,ED031000001,31 / 08 / 2015 19:30:00,Export varh Total,4.600000,kvarh",
"210095893,210095893,ED031000001,31 / 08 / 2015 19:45:00,Export varh Total,3.200000,kvarh",
"210095893,210095893,ED031000001,31 / 08 / 2015 20:00:00,Export varh Total,3.100000,kvarh",
"210095893,210095893,ED031000001,31 / 08 / 2015 20:15:00,Export varh Total,3.500000,kvarh",
"210095893,210095893,ED031000001,31 / 08 / 2015 20:30:00,Export varh Total,3.000000,kvarh",
"210095893,210095893,ED031000001,31 / 08 / 2015 22:00:00,Export varh Total,3.700000,kvarh"}.AsQueryable();
            int mockMedianIndex = 1;
            double[] result = ProviderUtility.GetMedianData(mockFileData, mockMedianIndex);
            int mockCountForAssert = 8;
            Assert.AreEqual(mockCountForAssert, result.Count());
        }

        /// <summary>
        /// Test method to validate if CalculateMedian returns the proper median for mocked data
        /// </summary>
        [TestMethod()]
        public void CalculateMedian_CheckValidDataTest()
        {
           double[] mockValues = { 3.9, 4.1, 4.6, 3.2, 3.1, 3.5, 3, 3.7 };
            double result = ProviderUtility.CalculateMedian(mockValues);
            double resultForAssert = 3.6;
            Assert.AreEqual(resultForAssert, result);
        }
    }
}